export interface IAction {
    type: string,
    data?: any;
}

export type Action = IAction;
