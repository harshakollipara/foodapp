export enum OrdersStateActionType {
  setOrderItems = 'SET_ORDER_ITEMS',
  cancelOrderItems = 'CANCEL_ORDER_ITEMS',
}

//setting order
export function setOrderItems(orderItemsData: any) {
  console.log('called setOrder', orderItemsData);
  return (dispatch: any) => {
    dispatch({
      type: OrdersStateActionType.setOrderItems,
      data: orderItemsData,
    });
  };
}

// canceling order
export function cancelOrderItems(orderItemsData: any) {
  return (dispatch: any) => {
    dispatch({
      type: OrdersStateActionType.cancelOrderItems,
      data: orderItemsData,
    });
  };
}

