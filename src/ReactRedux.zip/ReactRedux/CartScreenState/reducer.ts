import {Action} from '../action-type';
import {ICartState, defaultCartState} from './state';
import {CartStateActionType} from './action';

const cartStateReducer = (
  state: ICartState | undefined,
  action: Action,
): ICartState => {
  if (!state) {
    return defaultCartState();
  }

  if (action.type === CartStateActionType.addToCart) {
    return {
      cartItemsData: [...state.cartItemsData, action.data],
    };
  }

  if (action.type === CartStateActionType.removeFromCart) {
    return {
      cartItemsData: state.cartItemsData.filter(
        (removeItems: any) => removeItems.name !== action.data,
      ),
    };
  }

  if (action.type === CartStateActionType.emptyCartOnOrder) {
    return {
      cartItemsData: state.cartItemsData.filter((removeItems: any) => {
        removeItems.name !== action.data;
      }),
    };
  }

  return state;
};

export default cartStateReducer;
