export interface ICartState{
  cartItemsData: any[],
 
}

export function defaultCartState(): ICartState{
  return{
      cartItemsData:[],
  };
}